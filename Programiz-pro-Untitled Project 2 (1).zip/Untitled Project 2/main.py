sub1=int(input("enter marks of the first subject:"))
sub2=int(input("enter marks of the second subject:"))
sub3=int(input("enter marks of the  third subject:"))
sub4=int(input("enter marks of the fourth subject:"))
sub5=int(input("enter marks of the fifth subject:"))
avg=(sub1+sub2+sub3+sub4+sub5)/5
if(avg>=90):
    print("Grade:A+")
elif(avg>=80&avg<89):
    print("Grade:A")
elif(avg>=70&avg<79):
    print("Grade:B")
elif(avg>=60&avg<69):
    print("Grade:C")
elif(avg>=50&avg<59):
    print("Grade:D")
else:
    print("Grade F")
    

    
